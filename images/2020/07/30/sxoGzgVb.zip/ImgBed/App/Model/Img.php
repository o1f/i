<?php

namespace App\Model;

use QAQ\Kernel\Model;

class Img extends Model
{
    protected $table = 'img_imgs';
    protected $pk = 'img_id';

    public static function home_img_list($page)
    {
        $size = 50;
        $list = self::order('addtime', 'desc')
            ->page($page, $size)
            ->select();
        if (count($list) < 1) return [
            'code' => -1,
            'msg' => '没有更多了...'
        ];
        $img_list = [];
        foreach ($list as $k => $v) {
            $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
            $url = $http_type . $_SERVER['HTTP_HOST'] . '/api/img/' . $v['img_id'];
            $v['ip'] = explode('.', $v['ip']);
            $ip = $v['ip'][0] . '.' . $v['ip'][1] . '.***.' . $v['ip'][3];
            $img_list[] = [
                'url' => $url,
                'ip' => $ip,
                'addtime' => $v['addtime']
            ];
        }
        $count = self::count();
        return [
            'code' => 1,
            'data' => $img_list,
            'count' => $count,
            'page' => $page,
            'pages' => round($count / $size, 0)
        ];
    }

    public static function admin_img_list($page)
    {
        $size = 50;
        $list = self::order('addtime', 'desc')
            ->page($page, $size)
            ->select();
        if ($page != 1) {
            if (count($list) < 1) return [
                'code' => -1,
                'msg' => '没有更多了...'
            ];
        } else {
            if (count($list) < 1) return [
                'code' => 0
            ];
        }
        foreach ($list as $k => $v) {
            $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
            $url = $http_type . $_SERVER['HTTP_HOST'] . '/api/img/' . $v['img_id'];
            $list[$k]['url'] = $url;
        }
        $count = self::count();
        if ($count % $size == 0) {
            $pages = $count / $size;
        } else {
            $pages = (int)($count / $size) + 1;
        }
        return [
            'code' => 1,
            'data' => $list,
            'count' => $count,
            'page' => $page,
            'pages' => $pages
        ];
    }

    public static function get_img_ip($id)
    {
        return self::where(['img_id' => $id])->value('ip');
    }

    public static function del_img($id)
    {
        return self::where(['img_id' => $id])->delete();
    }

    public static function get_statistical()
    {
        $today = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
        $yesterday = mktime(0, 0, 0, date('m'), date('d') - 1, date('Y'));
        //今日上传文件数
        $today_uploads = self::where('addtime', '>=', $today)->count();
        //今日上传大小
        $today_upload_size = GetFileSize(self::where('addtime', '>=', $today)->sum('size'));
        //昨日上传文件数
        $yesterday_uploads = self::where('addtime', '>=', $yesterday)
            ->where('addtime', '<', $today)
            ->count();
        //昨日上传大小
        $yesterday_upload_size = GetFileSize(self::where('addtime', '>=', $yesterday)
            ->where('addtime', '<', $today)
            ->sum('size'));
        //总上传文件数
        $uploads = self::count();
        //总上传大小
        $upload_size = GetFileSize(self::sum('size'));
        return [
            'today_uploads' => $today_uploads,
            'today_upload_size' => $today_upload_size,
            'yesterday_uploads' => $yesterday_uploads,
            'yesterday_upload_size' => $yesterday_upload_size,
            'uploads' => $uploads,
            'upload_size' => $upload_size
        ];
    }

    public static function get_one_hour_uploads()
    {
        return self::where(
            'addtime',
            '>=',
            time() - 3600
        )->count();
    }
}