INSERT INTO `img_config` (`k`, `v`) VALUES ('username', 'admin');
INSERT INTO `img_config` (`k`, `v`) VALUES ('password', '123456');
INSERT INTO `img_config` (`k`, `v`) VALUES ('one_hour_uploads', '100');
ALTER TABLE `img_imgs` ADD `sex_verify` INT(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT '鉴黄状态' AFTER `size`;