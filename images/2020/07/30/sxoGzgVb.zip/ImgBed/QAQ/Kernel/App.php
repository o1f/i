<?php
/*
 * QAQ APP引擎
 * Author:烟雨寒云
 * Mail:admin@yyhy.me
 * Date:2020/04/18
 */

namespace QAQ\Kernel;

class App
{
    protected $s;
    protected $url;
    protected $module;
    protected $controller;
    protected $action;
    protected $class;
    protected $value;

    private function __construct()
    {
        if (isset($_GET['s']) && !empty($_GET['s'])) {
            $url = $_GET['s'];
        } else {
            $url = '/index';
        }
        $this->s = $url;
        $_url = explode('/', $url);
        //去空
        $_url = array_filter($_url);
        //重新排列下标
        $url = [];
        foreach ($_url as $k => $v) {
            $url[] = $v;
        }
        if (count($url) < 2) $url[1] = 'index';
        if (Config::get('multi_app')) {
            if (count($url) < 3) $url[2] = 'index';
            $this->module = $url[0];
            $this->controller = $url[1];
            $this->action = $url[2];
            $value = [];
            for ($i = 0; $i < count($url); $i++) {
                if ($i > 2) {
                    $value[] = $url[$i];
                }
            }
        } else {
            $this->controller = $url[0];
            $this->action = $url[1];
            $value = [];
            for ($i = 0; $i < count($url); $i++) {
                if ($i > 1) {
                    $value[] = $url[$i];
                }
            }
        }
        $this->url = $url;
        $this->value = $value;
    }

    public static function run()
    {
        $static = new static();
        if (Config::get('must_route')) {
            return $static->RunWithRoute();
        } else {
            if (Config::get('multi_app')) {
                return $static->FindModule();
            } else {
                $static->module = 'App\\Controller\\';
                return $static->FindController();
            }
        }
    }

    public function controller()
    {
        return $this->controller;
    }

    public function module()
    {
        return $this->module;
    }

    public function action()
    {
        return $this->action;
    }

    private function RunWithRoute()
    {
        $url = $this->s;
        $routes = Route::register(Config::get('route_files'))->GetRules();
        $request_type = self::RequestType();
        if (!self::GetRuleWithOutType($url, $routes)) {
            $rule = self::GetRuleWithType($url, $routes, $request_type);
        } else {
            $rule = self::GetRuleWithOutType($url, $routes);
        }
        if (!$rule) {
            throw new \Exception('QAQ Route Rule Not Found！', -2000);
        }
        if (!isset(array_keys($rule)[0])) {
            throw new \Exception('QAQ Route Rule Not Found！', -2000);
        }
        $route_url = array_keys($rule)[0];
        $rule = $rule[$route_url];
        //进行参数处理
        $value = str_replace($route_url, '', $url);
        $rule = $rule . $value;
        $_url = explode('/', $rule);
        //去空
        $_url = array_filter($_url);
        //重新排列下标
        $url = [];
        foreach ($_url as $k => $v) {
            $url[] = $v;
        }
        if (count($url) < 2) $url[1] = 'index';
        if (count($url) < 3) $url[2] = 'index';
        $this->url = $url;
        if (Config::get('multi_app')) {
            $this->module = $url[0];
            $this->controller = $url[1];
            $this->action = $url[2];
            $value = [];
            for ($i = 0; $i < count($url); $i++) {
                if ($i > 2) {
                    $value[] = $url[$i];
                }
            }
        } else {
            $this->controller = $url[0];
            $this->action = $url[1];
            $value = [];
            for ($i = 0; $i < count($url); $i++) {
                if ($i > 1) {
                    $value[] = $url[$i];
                }
            }
        }
        $this->value = $value;
        if (Config::get('multi_app')) {
            return $this->FindModule();
        } else {
            $this->module = 'App\\Controller\\';
            return $this->FindController();
        }
    }

    private static function GetRuleWithOutType($url, $routes)
    {
        $_routes = $routes['rule'];
        $preg = [];
        foreach ($_routes as $k => $v) {
            if ($url == $k) return [
                $k => $v
            ];
            if (strpos($url, $k) !== false && strpos($url, $k) < 1) {
                $preg[][$k]['len'] = strlen(explode($k, $url)[1] ?? '');
            }
        }
        if (count($preg) > 0) {
            ksort($preg);
            if (!isset(array_keys($preg[0])[0])) return false;
            if (!isset($_routes[array_keys($preg[0])[0]])) return false;
            return [
                array_keys($preg[0])[0] => $_routes[array_keys($preg[0])[0]]
            ];
        }
        return false;
    }

    private static function GetRuleWithType($url, $routes, $request_type)
    {
        $_routes = $routes[$request_type];
        $preg = [];
        foreach ($_routes as $k => $v) {
            $_url = explode('/', $k);
            //去空
            $_url = array_filter($_url);
            $k = '';
            foreach ($_url as $u) {
                $k .= '/' . $u;
            }
            if ($url == $k) return [
                $k => $v
            ];
            if (strpos($url, $k) !== false && strpos($url, $k) < 1) {
                $preg[][$k]['len'] = strlen(explode($k, $url)[1] ?? '');
            }
        }
        if (count($preg) > 0) {
            ksort($preg);
            if (!isset(array_keys($preg[0])[0])) return false;
            if (!isset($_routes[array_keys($preg[0])[0]])) return false;
            return [
                array_keys($preg[0])[0] => $_routes[array_keys($preg[0])[0]]
            ];
        }
        return false;
    }

    private static function RequestType()
    {
        return $_SERVER['REQUEST_METHOD'] == 'GET' ? 'get' : 'post';
    }

    private function FindModule()
    {
        //应用目录
        $App_Dir = \QAQ::DirMap('App');
        //寻找模块
        $module_file = $App_Dir . '/Controller/' . $this->module;
        $this->module = 'App\\Controller\\' . $this->module . '\\';
        if (!is_dir($module_file)) {
            $module_file = $App_Dir . '/Controller/' . ucfirst($this->module);
            $this->module = 'App\\Controller\\' . ucfirst($this->module) . '\\';
            if (!is_dir($module_file)) {
                throw new \Exception('QAQ Module Not Found！', -2001);
            }
        }
        //匹配控制器层
        return $this->FindController();
    }

    private function FindController()
    {
        $this->class = $this->module . $this->controller;
        if (!class_exists($this->class)) {
            $this->controller = ucfirst($this->controller);
            $this->class = $this->module . $this->controller;
            if (!class_exists($this->class)) {
                throw new \Exception('QAQ Controller Not Found！', -2002);
            }
        }
        //匹配控制器方法
        return $this->FindAction();
    }

    private function FindAction()
    {
        if (!method_exists($this->class, $this->action)) {
            $this->action = ucfirst($this->action);
            if (!method_exists($this->class, $this->action)) {
                throw new \Exception('QAQ Action Not Found！', -2003);
            }
        }
        //执行控制器代码
        $class = new $this->class;
        $action = $this->action;
        return call_user_func_array([
            $class, $action
        ], $this->value);
    }
}