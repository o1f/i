const generateOverride = (params = {}) => {
    let result = ''
    if (params.card_bg) {
        result += `
      #usercard .card-bg {
        background-image: url('${params.card_bg}');
        background-position: center center;
        background-repeat: no-repeat;
        background-attachment: scroll;
        background-size: cover;
    }
    `
    }
    if (params.body_bg) {
        result += ` 
        #body_bg{
        background-color: ${params.body_bg};
      }
      `
    }
    return result
}

module.exports = generateOverride